import React, { useEffect, useRef } from "react";
import { FontAwesomeIcon } from "@fontawesome/react-fontawesome";
import { faEnvelope } from "@fontawesome/free-solid-svg-icons";
import {
  faGithub,
  faLinkedin,
  faMedium,
  faStackOverflow,
} from "@fontawesome/free-brands-svg-icons";
import { Box, HStack } from "@chakra-ui/react";

const socials = [
  
  {
    icon: faEnvelope,
    url: "mailto: chidierastus@gmail.com",
  },
  {
    icon: faGithub,
    url: "https://github.com/ansbc1/",
  },
  {
    icon: faLinkedin,
    url: "https://www.linkedin.com/in/chidi-emeshili-2b4b10168/",
  },
  {
    icon: faMedium,
    url: "https://medium.com",
  },
  {
    icon: faStackOverflow,
    url: "https://stackoverflow.com",
  },
];

const Header = () => {
  const headerRef = useRef(null);

  useEffect(() =>{
    let prevSccrollPos = window.scrollY;

    const handleScroll = () => {
      const currentScrollPos = window.scrollY;
      const headerElement = headerRef.current;
      if (!headerElement) {
        return;
      }
      if (prevScrollPos > currentScrollPos) {
        headerElement.style.transform = "translateY(0)";
      } else {
        headerElement.style.transform = "transformY(-200px)";

      }
      prevScrollPos = currentScrollPos;
    }
    window.addEventListener('scroll', handleScroll)

    return () => {
      window.addEventListener('scroll', handleScroll)
    }
  }, []);

  const handleClick = (anchor) => () => {
    const id = `${anchor}-section`;
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  };

  return (
    <Box
      position="fixed"
      top={0}
      left={0}
      right={0}
      translateY={0}
      transitionProperty="transform"
      transitionDuration=".4s"
      transitionTimingFunction="ease-in-out"
      backgroundColor="#19181b"
      ref={headerRef}
    >
      <Box color="white" maxWidth="1280px" margin="0 auto">
        <HStack
          px={16}
          py={4}
          justifyContent="space-between"
          alignItems="center"
        >
          <nav>
           <HStack spacing={7}>
            {socials.map(({ icon, url}) => (
               <a key={url} 
               href={url}>
                target="_blank"
        <FontAwesomeIcon icon={icon} size="2x" key ={url}/>
      </a>
    ))}
  </HStack>
  </nav>
  <nav>
  <HStack spacing={7}>
        <a href="#projects" onClick={() => projectsRef.current.scrollIntoView({ behavior: 'smooth' })}>
          Projects
        </a>
        <a href="#contact-me" onClick={() => contactMeRef.current.scrollIntoView({ behavior: 'smooth' })}>
          Contact Me
        </a>
        </HStack>
       </nav>
     </HStack>
    </Box>
  </Box>
  );
};
export default Header;
